#!/usr/bin/env python2.7
#################################################################################
##
## Xpedite auto generated file
##
#################################################################################

import os
from xpedite import Probe, TxnBeginProbe, TxnEndProbe
from xpedite.pmu.event import Event
from xpedite.txn.classifier import ProbeDataClassifier
from xpedite import TopdownNode, Metric, Event, ResultOrder

# Name of the application
appName = 'slowFixDecoderApp'

# Host, where the applciation is running
appHost = 'localhost'

# Path of the appinfo file, configured in the application while initializing xpedite framework
appInfo = 'xpedite-appinfo.txt'

################################################## Probe List ##################################################
# Probes when enabled collect samples druing execution. The probes listed here are enabled during "xpedite record"
# Probes with types TxnBeginProbe and TxnEndProbe mark the beginning and end of transactions respectively. 
probes = [
  Probe('Parse Account', sysName = 'ParseAccount'),
  Probe('Parse Begin Msg', sysName = 'ParseBeginMsg'),
  Probe('Parse Body Length', sysName = 'ParseBodyLength'),
  Probe('Parse Cl Order Id', sysName = 'ParseClOrderId'),
  TxnBeginProbe('Parse Fix Begin', sysName = 'ParseFixBegin'),
  TxnEndProbe('Parse Fix End', sysName = 'ParseFixEnd'),
  Probe('Parse Handler Inst', sysName = 'ParseHandlerInst'),
  Probe('Parse Host', sysName = 'ParseHost'),
  Probe('Parse Message Seq Num', sysName = 'ParseMessageSeqNum'),
  Probe('Parse Message Type', sysName = 'ParseMessageType'),
  Probe('Parse Order Type', sysName = 'ParseOrderType'),
  Probe('Parse Price', sysName = 'ParsePrice'),
  Probe('Parse Qty', sysName = 'ParseQty'),
  Probe('Parse Sender Comp Id', sysName = 'ParseSenderCompId'),
  Probe('Parse Sending Time', sysName = 'ParseSendingTime'),
  Probe('Parse Side', sysName = 'ParseSide'),
  Probe('Parse Symbol', sysName = 'ParseSymbol'),
  Probe('Parse Time In Force', sysName = 'ParseTimeInForce'),
]

benchmarkPaths = None
pmc = None
