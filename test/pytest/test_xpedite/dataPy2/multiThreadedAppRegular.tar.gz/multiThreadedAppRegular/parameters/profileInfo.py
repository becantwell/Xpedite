#!/usr/bin/env python2.7
#################################################################################
##
## Xpedite auto generated file
##
#################################################################################

from xpedite import Probe, TxnBeginProbe, TxnSuspendProbe, TxnResumeProbe, TxnEndProbe
from xpedite.txn.classifier import ProbeDataClassifier
from xpedite import TopdownNode, Metric, Event, ResultOrder

# Name of the application
appName = 'multiThreadedApp'

# Host, where the applciation is running
appHost = '127.0.0.1'

# Path of the appinfo file, configured in the application while initializing xpedite framework
appInfo = 'xpedite-appinfo.txt'

################################################## Probe List ##################################################
# Probes when enabled collect samples druing execution. The probes listed here are enabled during "xpedite record"
# Probes with types TxnBeginProbe and TxnEndProbe mark the beginning and end of transactions respectively. 
probes = [
  TxnBeginProbe('Task Begin', sysName = 'TaskBegin'),
  TxnEndProbe('Task End', sysName = 'TaskEnd'),
  TxnResumeProbe('Task Resume', sysName = 'TaskResume'),
  TxnSuspendProbe('Task Suspend', sysName = 'TaskSuspend'),
]

benchmarkPaths = None
pmc = None
